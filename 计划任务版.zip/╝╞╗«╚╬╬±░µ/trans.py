import markdown
import datetime
import os
import glob
import re
import shutil
import sys
import logging
from logging.handlers import RotatingFileHandler

# ==================== 配置区 ====================
REVERSE_ORDER = True

# 日志配置
LOG_FOLDER = "logs"
LOG_FILE = os.path.join(LOG_FOLDER, "diary_trans.log")
LOG_MAX_SIZE = 10 * 1024 * 1024  # 10MB
LOG_BACKUP_COUNT = 5
# ==============================================

WEEKDAY_MAP = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def setup_logger():
    """配置日志系统"""
    os.makedirs(LOG_FOLDER, exist_ok=True)

    logger = logging.getLogger('DiaryTrans')
    logger.setLevel(logging.INFO)

    # 文件处理器
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=LOG_MAX_SIZE,
        backupCount=LOG_BACKUP_COUNT,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)

    # 日志格式
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    return logger


logger = setup_logger()


def main():
    try:
        logger.info("=" * 50)
        logger.info("开始HTML生成任务")

        # 接受 base_folder 参数
        if len(sys.argv) > 1:
            base_folder = sys.argv[1]
        else:
            base_folder = "myself"

        logger.info(f"目标文件夹: {base_folder}")

        TEMPLATE_FILE = os.path.join(base_folder, "html", "template.html")
        if not os.path.exists(TEMPLATE_FILE):
            logger.error(f"{TEMPLATE_FILE} 不存在！")
            raise FileNotFoundError(f"{TEMPLATE_FILE} 不存在！")

        with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
            TEMPLATE = f.read()

        input_folder = os.path.join(base_folder, "markdown")
        output_dir = os.path.join(base_folder, "html", "output")
        pictures_folder = os.path.join(output_dir, "Pictures")
        os.makedirs(pictures_folder, exist_ok=True)

        # 查找所有markdown文件
        filepaths = sorted(glob.glob(os.path.join(
            input_folder, "**/*.md"), recursive=True))

        if not filepaths:
            logger.warning(f"在 {input_folder} 中未找到任何 Markdown 文件")
            return

        logger.info(f"找到 {len(filepaths)} 个 Markdown 文件")

        if REVERSE_ORDER:
            filepaths = list(reversed(filepaths))

        diaries_html = []
        processed_count = 0

        for filepath in filepaths:
            try:
                filename = os.path.basename(filepath)
                name, _ = os.path.splitext(filename)

                with open(filepath, "r", encoding="utf-8") as f:
                    diary_md = f.read()

                # 移除第一行日期标记
                diary_md = re.sub(r'^\s*.*\n', '', diary_md, count=1)

                # 处理图片
                for md_img_match in re.findall(r'!\[.*?\]\((.*?)\)', diary_md):
                    img_name = os.path.basename(md_img_match)
                    original_img_path = os.path.join(
                        os.path.dirname(filepath), md_img_match)

                    if os.path.exists(original_img_path):
                        shutil.copy2(original_img_path, os.path.join(
                            pictures_folder, img_name))

                    diary_md = diary_md.replace(
                        md_img_match, f"./Pictures/{img_name}")

                # 转换为HTML
                diary_html = markdown.markdown(
                    diary_md, extensions=["fenced_code", "tables", "nl2br"])

                # 解析日期
                try:
                    date = datetime.datetime.strptime(name, "%Y-%m-%d").date()
                except:
                    date = datetime.date.today()
                    logger.warning(f"无法解析日期: {name}，使用今天日期")

                weekday = WEEKDAY_MAP[date.weekday()]

                article = f"""
<article class="diary">
  <header class="meta">
    <div class="date">{date}</div>
    <div class="weekday">{weekday}</div>
  </header>
  <h1 class="title"></h1>
  <section class="content">{diary_html}</section>
</article>
"""
                diaries_html.append(article)
                processed_count += 1

            except Exception as e:
                logger.error(f"处理文件 {filepath} 时出错: {e}")
                continue

        logger.info(f"成功处理 {processed_count}/{len(filepaths)} 个文件")

        # 生成最终HTML
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, "diaries.html")

        with open(output_file, "w", encoding="utf-8") as f:
            f.write(TEMPLATE.replace(
                "{{CONTENT_HTML}}", "\n".join(diaries_html)))

        # 拷贝 logo 和背景
        for fname in ["logo.png", "background.png"]:
            src = os.path.join(base_folder, "html", fname)
            dst = os.path.join(output_dir, fname)
            if os.path.exists(src):
                shutil.copy2(src, dst)

        logger.info(f"已生成 {output_file}")
        logger.info("HTML生成任务完成！")
        logger.info("=" * 50)

    except Exception as e:
        logger.error(f"HTML生成失败: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
