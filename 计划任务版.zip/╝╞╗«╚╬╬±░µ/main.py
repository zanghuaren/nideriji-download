import requests
import os
import re
import base64
from Crypto.Cipher import AES
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess
import sys
import shutil
import json
import logging
from logging.handlers import RotatingFileHandler

# ==================== 配置区 ====================
EMAIL = ""
PASSWORD = ""
SYNC_PARTNER = False  # True=同步搭档日记, False=同步自己的日记
ORDER_OLD_TO_NEW = True
MAX_WORKERS = 5
AUTO_GENERATE_HTML = True  # 自动生成HTML
DOWNLOAD_IMAGES_ONLY_DEFAULT = True

# 日志配置
LOG_FOLDER = "logs"
LOG_FILE = os.path.join(LOG_FOLDER, "diary_sync.log")
LOG_MAX_SIZE = 10 * 1024 * 1024  # 10MB
LOG_BACKUP_COUNT = 5
# ==============================================


def setup_logger():
    """配置日志系统"""
    os.makedirs(LOG_FOLDER, exist_ok=True)

    logger = logging.getLogger('DiarySync')
    logger.setLevel(logging.INFO)

    # 文件处理器 - 带日志轮转
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=LOG_MAX_SIZE,
        backupCount=LOG_BACKUP_COUNT,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)

    # 日志格式
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    return logger


logger = setup_logger()


def get_sync_state_file(partner=False):
    """获取同步状态文件路径"""
    base_folder = "partner" if partner else "myself"
    return os.path.join(base_folder, ".sync_state.json")


def load_sync_state(partner=False):
    """加载同步状态"""
    state_file = get_sync_state_file(partner)
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"读取同步状态失败: {e}")
    return {
        'last_sync_time': None,
        'synced_diary_ids': [],
        'synced_image_ids': []
    }


def save_sync_state(state, partner=False):
    """保存同步状态"""
    state_file = get_sync_state_file(partner)
    try:
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
        logger.info("同步状态已保存")
    except Exception as e:
        logger.error(f"保存同步状态失败: {e}")


def login(email, password):
    url = "https://nideriji.cn/api/login/"
    headers = {'User-Agent': 'OhApp/3.6.12 Platform/Android'}
    data = {'email': email, 'password': password}
    try:
        r = requests.post(url, headers=headers, data=data, timeout=10)
        r.raise_for_status()
        token = r.json().get('token')
        if not token:
            raise ValueError("登录失败，未获取到 token")
        logger.info("登录成功")
        return token
    except Exception as e:
        logger.error(f"登录失败: {e}")
        raise


def clean_unicode(text):
    for prefix in ["\\ud83c", "\\ud83d", "\\ud83e"]:
        text = text.replace(prefix, "")
    return text


def decrypt_privacy(content, user_id):
    def decrypt_block(match):
        cipher_text = match.group(1)
        key = str(user_id).encode('utf-8')
        aes = AES.new(key.ljust(16, b'\0'), AES.MODE_ECB)
        try:
            decrypted = aes.decrypt(bytes.fromhex(cipher_text))
            return "[隐私区域开始]" + decrypted.decode('utf-8', errors='ignore') + "[隐私区域结束]"
        except:
            try:
                decrypted = aes.decrypt(base64.b64decode(cipher_text))
                return "[隐私区域开始]" + decrypted.decode('utf-8', errors='ignore') + "[隐私区域结束]"
            except:
                return match.group(0)
    pattern = re.compile(
        r"\[以下是隐私区域密文，请不要做任何编辑，否则可能导致解密失败\]([\s\S]+?)\[以上是隐私日记，请不要编辑密文\]")
    return pattern.sub(decrypt_block, content)


def get_diaries_overview(token, partner=False):
    headers = {'auth': f'token {token}',
               'User-Agent': 'OhApp/3.6.12 Platform/Android'}
    try:
        r = requests.post("https://nideriji.cn/api/v2/sync/",
                          headers=headers,
                          data={'user_config_ts': '0', 'diaries_ts': '0',
                                'readmark_ts': '0', 'images_ts': '0'},
                          timeout=15)
        r.raise_for_status()
        data = r.json()

        if partner:
            diaries = data.get('diaries_paired', [])
            all_image_ids = [img['image_id']
                             for img in data.get('images_paired', [])]
            user_id = data['user_config']['paired_user_config']['userid']
        else:
            diaries = data.get('diaries', [])
            all_image_ids = [img['image_id'] for img in data.get('images', [])]
            user_id = data['user_config']['userid']

        logger.info(f"获取到 {len(all_image_ids)} 张图片 ID")
        if diaries:
            logger.info(
                f"获取日记总数: {len(diaries)} 篇，日期范围: {diaries[-1]['createddate']} - {diaries[0]['createddate']}")
        return diaries, user_id, all_image_ids
    except Exception as e:
        logger.error(f"获取日记概览失败: {e}")
        raise


def get_diary_full(token, user_id, diary_id):
    headers = {'auth': f'token {token}',
               'User-Agent': 'OhApp/3.6.12 Platform/Android'}
    try:
        r = requests.post(f"https://nideriji.cn/api/diary/all_by_ids/{user_id}/",
                          headers=headers,
                          data={'diary_ids': diary_id},
                          timeout=10)
        r.raise_for_status()
        data = r.json()
        if 'diaries' in data and data['diaries']:
            d = data['diaries'][0]
            d['content'] = clean_unicode(d.get('content', ''))
            d['content'] = decrypt_privacy(d['content'], user_id)
            return d
        return None
    except Exception as e:
        logger.warning(f"获取日记 {diary_id} 失败: {e}")
        return None


def filter_new_diaries(diaries, sync_state, days=3):
    synced_ids = set(sync_state['synced_diary_ids'])

    today = datetime.date.today()
    cutoff_date = today - datetime.timedelta(days=days - 1)

    def need_sync(d):
        diary_date = datetime.datetime.strptime(
            d['createddate'], "%Y-%m-%d"
        ).date()

        # 条件 1：从未同步过
        if d['id'] not in synced_ids:
            return True

        # 条件 2：最近 N 天内的日记（兜底）
        if diary_date >= cutoff_date:
            return True

        return False

    target_diaries = [d for d in diaries if need_sync(d)]
    target_diaries.sort(key=lambda x: x['createddate'],
                        reverse=not ORDER_OLD_TO_NEW)

    logger.info(
        f"共 {len(diaries)} 篇日记，"
        f"其中 {len(target_diaries)} 篇需要同步."
    )
    return target_diaries


def save_diary(diary, markdown_folder):
    diary_date = datetime.datetime.strptime(
        diary['createddate'], "%Y-%m-%d").date()
    folder_name = os.path.join(
        markdown_folder, f"{diary_date.year}-{diary_date.month:02d}")
    os.makedirs(folder_name, exist_ok=True)
    filename = os.path.join(folder_name, f"{diary_date}.md")

    with open(filename, 'w', encoding='utf-8') as f:
        weekday = diary.get('weekday', '')
        f.write(f"=={diary['createddate']} {weekday}==\n")
        f.write(diary.get('title', '') + '\n')
        f.write(diary.get('content', ''))

    logger.debug(f"已保存日记: {filename}")


def download_image(image_id, user_id, headers, pictures_folder):
    """下载单张图片"""
    url = f"https://f.nideriji.cn/api/image/{user_id}/{image_id}/"
    try:
        r = requests.get(url, headers=headers, timeout=15)
        r.raise_for_status()
        filepath = os.path.join(pictures_folder, f"{image_id}.jpg")
        with open(filepath, 'wb') as f:
            f.write(r.content)
        return image_id, True
    except Exception as e:
        logger.warning(f"下载图片 {image_id} 失败: {e}")
        return image_id, False


def download_new_images(all_image_ids, user_id, headers, pictures_folder, sync_state):
    """增量下载新图片"""
    os.makedirs(pictures_folder, exist_ok=True)

    synced_images = set(sync_state['synced_image_ids'])
    new_image_ids = [
        img_id for img_id in all_image_ids if img_id not in synced_images]

    if not new_image_ids:
        logger.info("没有新图片需要下载")
        return []

    logger.info(f"开始下载 {len(new_image_ids)} 张新图片")

    downloaded = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(download_image, img_id, user_id, headers, pictures_folder): img_id
                   for img_id in new_image_ids}

        for future in futures:
            img_id, success = future.result()
            if success:
                downloaded.append(img_id)

    logger.info(f"成功下载 {len(downloaded)}/{len(new_image_ids)} 张图片")
    return downloaded


def replace_images_in_markdown(diaries, markdown_folder, pictures_folder):
    for d in diaries:
        diary_date = datetime.datetime.strptime(
            d['createddate'], "%Y-%m-%d").date()
        folder_name = os.path.join(
            markdown_folder, f"{diary_date.year}-{diary_date.month:02d}")
        md_file = os.path.join(folder_name, f"{diary_date}.md")

        if not os.path.exists(md_file):
            continue

        with open(md_file, 'r', encoding='utf-8') as f:
            content = f.read()

        content = re.sub(
            r'\[图(\d+)\]',
            lambda m: f"![img]({os.path.join(pictures_folder, f'{m.group(1)}.jpg')})",
            content
        )

        with open(md_file, 'w', encoding='utf-8') as f:
            f.write(content)


def run_trans_script(base_folder):
    try:
        result = subprocess.run([sys.executable, "trans.py", base_folder],
                                capture_output=True, text=True)
        if result.returncode == 0:
            logger.info("HTML文件生成成功！")
            return True
        else:
            logger.error(f"HTML文件生成失败: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"运行 trans.py 时出错: {e}")
        return False


def main():
    try:
        logger.info("=" * 50)
        logger.info("开始日记同步任务")

        # 登录
        token = login(EMAIL, PASSWORD)

        # 确定同步对象
        partner = SYNC_PARTNER
        base_folder = "partner" if partner else "myself"
        markdown_folder = os.path.join(base_folder, "markdown")
        html_folder = os.path.join(base_folder, "html")
        pictures_folder = os.path.join(html_folder, "output", "Pictures")

        # 创建目录
        os.makedirs(markdown_folder, exist_ok=True)
        os.makedirs(html_folder, exist_ok=True)
        os.makedirs(os.path.join(html_folder, "output"), exist_ok=True)

        # 拷贝模板文件
        src_html_dir = "html"
        for fname in ["template.html", "logo.png", "background.png"]:
            src = os.path.join(src_html_dir, fname)
            dst = os.path.join(html_folder, fname)
            if os.path.exists(src):
                shutil.copy2(src, dst)

        # 加载同步状态
        sync_state = load_sync_state(partner)

        # 获取日记概览
        diaries_overview, user_id, all_image_ids = get_diaries_overview(
            token, partner)

        # 筛选新日记
        new_diaries = filter_new_diaries(diaries_overview, sync_state, days=3)

        if not new_diaries:
            logger.info("没有新日记需要同步")
        else:
            # 下载新日记
            logger.info(f"开始下载 {len(new_diaries)} 篇新日记...")
            headers = {'auth': f'token {token}',
                       'User-Agent': 'OhApp/3.6.12 Platform/Android'}

            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(get_diary_full, token, user_id, d['id'])
                           for d in new_diaries]

                full_diaries = []
                for future in futures:
                    diary = future.result()
                    if diary:
                        save_diary(diary, markdown_folder)
                        full_diaries.append(diary)
                        sync_state['synced_diary_ids'].append(diary['id'])

            logger.info(f"成功同步 {len(full_diaries)} 篇日记")

            # 下载新图片
            downloaded_images = download_new_images(
                all_image_ids, user_id, headers, pictures_folder, sync_state
            )
            sync_state['synced_image_ids'].extend(downloaded_images)

            # 替换图片路径
            if full_diaries:
                replace_images_in_markdown(
                    full_diaries, markdown_folder, "./Pictures")

        # 更新同步时间
        sync_state['last_sync_time'] = datetime.datetime.now().isoformat()
        save_sync_state(sync_state, partner)

        # 生成HTML
        if AUTO_GENERATE_HTML:
            logger.info("开始生成HTML文件...")
            if run_trans_script(base_folder):
                logger.info(f"HTML文件已生成在 {html_folder}/output/ 目录")
            else:
                logger.warning("HTML生成失败，但Markdown文件已保存")

        logger.info("日记同步任务完成！")
        logger.info("=" * 50)

    except Exception as e:
        logger.error(f"同步任务失败: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
